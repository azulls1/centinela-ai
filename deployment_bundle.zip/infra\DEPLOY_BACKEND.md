# Despliegue del backend con Docker Swarm

Esta guía complementa los pasos manuales en el VPS (por ejemplo, Contabo) para desplegar el backend con Docker Swarm, Portainer y un stack `vision-stack`.

## 1. Preparar archivos localmente

1. Copia las carpetas de código:
   - `apps/api`
   - `apps/stream-gateway`
2. Asegúrate de que existan los Dockerfile:
   - `apps/api/Dockerfile`
   - `apps/stream-gateway/Dockerfile` (instala `ffmpeg` y arranca el servicio en `:8081`).
3. Crea un archivo `.env.production` basado en `infra/.env.production.example` con tus valores reales.
4. Revisa o ajusta `infra/stack.yml` si necesitas más servicios (proxy, Redis, etc.).

## 2. Subir archivos al VPS

1. Conéctate por SFTP/WinSCP al servidor.
2. Crea la estructura (ejemplo):
   ```
   /opt/vision-backend/
     ├─ source/
     │    ├─ apps/
     │    │   ├─ api/
     │    │   └─ stream-gateway/
     │    ├─ stack.yml
     │    └─ .env.production
   ```
3. Sube las carpetas `apps/api`, `apps/stream-gateway`, el `stack.yml` y tu `.env.production`.
4. Ajusta permisos:
   ```bash
   chmod 600 /opt/vision-backend/.env.production
   ```

## 3. Construir imágenes en el nodo

```bash
cd /opt/vision-backend/source
docker build -t vision-api:latest ./apps/api
docker build -t vision-stream-gateway:latest ./apps/stream-gateway
```

Si usas varios nodos en el swarm, sube estas imágenes a un registry compartido.

## 4. Desplegar el stack

```bash
cd /opt/vision-backend
docker stack deploy -c source/stack.yml vision-stack --with-registry-auth
```

Monitorea:
```bash
docker stack services vision-stack
docker service logs -f vision-stack_api
docker service logs -f vision-stack_stream-gateway
```

## 5. Variables y secretos

- El stack carga variables desde `infra/.env.production` (en el servidor renómbralo a `.env.production`).
- Para mayor seguridad puedes convertir claves en *Docker secrets*; ajusta el `stack.yml` según tus necesidades.

## 6. Integración con Portainer

- En Portainer, ve a *Stacks* → *Add stack* → *Web editor* o *Upload* y pega el contenido de `stack.yml`.
- Selecciona la misma `.env.production` como archivo de variables.
- Despliega y revisa que los servicios estén en estado `Running`.

## 7. Puertos y dominios

- El API expone `8000`.
- El Stream Gateway expone `8081`.
- Configura DNS/reverse proxy si necesitas HTTPS (Traefik, Nginx, Caddy, etc.).

## 8. Verificación rápida

```bash
curl http://TU_IP:8000/api/health
curl http://TU_IP:8081/health
```

Si todo responde `ok`, actualiza el frontend (`VITE_API_BASE_URL`, `VITE_STREAM_GATEWAY_URL`) para apuntar a estos endpoints públicos.


